<div class="max-h-[550px] overflow-y-auto block">
  <table class="w-full border-spacing-y-2 border-separate">
    <thead class="bg-Analytics-secondary sticky top-0 z-10 flex-shrink-0">
      <tr>
        <th class=" pl-6 text-left text-sm font-semibold text-white py-4">Document Details</th>
        <th class=" px-3 text-left text-sm font-semibold text-white">Status</th>
        <th class=" px-3 text-left text-sm font-semibold text-white">Document Id</th>
        <th class=" px-3 text-left text-sm font-semibold text-white pl-28">Actions</th>
        <!-- <th class="text-left text-sm font-semibold text-white">Preview</th> -->
      </tr>
    </thead>
    <tbody>
      <tr>
        <td class="whitespace-nowrap py-2 pl-4 pr-3 text-sm sm:pl-6 border-y-2 border-l-2 border-Analytics-sidebar">
          <div class="flex items-center">
            <div class="h-10 w-10 flex-shrink-0">
              <img class="h-10 w-10 rounded-sm" src="https://media.istockphoto.com/id/828088276/vector/qr-code-illustration.jpg?s=612x612&w=0&k=20&c=FnA7agr57XpFi081ZT5sEmxhLytMBlK4vzdQxt8A70M=" alt="" />
            </div>
            <div class="ml-4">
              <div class="font-medium text-Analytics-primarytext">Fixed Deposit Receipt</div>
              <div class="text-Analytics-primarytext">Wed Jan 18 2023</div>
            </div>
          </div>
        </td>
        <td class="whitespace-nowrap px-3 py-2 text-base text-Analytics-primarytext border-y-2  border-Analytics-sidebar">
          <div class="text-green-500 font-medium">Active</div>
        </td>
        <td class="whitespace-nowrap px-3 py-2 text-sm text-Analytics-primarytext border-y-2  border-Analytics-sidebar">63779af36cb6b239c0215c8c</td>
        <td class="relative whitespace-nowrap py-2 pl-3 pr-4 text-right text-sm font-medium border-y-2 border-r-2 border-Analytics-sidebar">
          <div class="flex gap-5 items-center justify-end">
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" class="w-7 h-7 stroke-blue-500">
                <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 18L9 11.25l4.306 4.307a11.95 11.95 0 015.814-5.519l2.74-1.22m0 0l-5.94-2.28m5.94 2.28l-2.28 5.941" />
              </svg>
            </span>
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 fill-yellow-500" viewBox="0 0 24 24"><path d="M12 2c5.5 0 10 4.5 10 10s-4.5 10-10 10S2 17.5 2 12S6.5 2 12 2m0 2c-1.9 0-3.6.6-4.9 1.7l11.2 11.2c1-1.4 1.7-3.1 1.7-4.9c0-4.4-3.6-8-8-8m4.9 14.3L5.7 7.1C4.6 8.4 4 10.1 4 12c0 4.4 3.6 8 8 8c1.9 0 3.6-.6 4.9-1.7Z" /></svg>
            </span>
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 stroke-slate-400" viewBox="0 0 16 16">
                <g fill="currentColor">
                  <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z" />
                  <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z" />
                </g>
              </svg>
            </span>
            <button class="px-4 py-2 border border-Analytics-sidebar text-Analytics-iconcolor hover:bg-Analytics-iconcolor hover:text-white">View</button>
          </div>
        </td>
      </tr>
      <tr>
        <td class="whitespace-nowrap py-2 pl-4 pr-3 text-sm sm:pl-6 border-y-2 border-l-2 border-Analytics-sidebar">
          <div class="flex items-center">
            <div class="h-10 w-10 flex-shrink-0">
              <img class="h-10 w-10 rounded-sm" src="https://media.istockphoto.com/id/828088276/vector/qr-code-illustration.jpg?s=612x612&w=0&k=20&c=FnA7agr57XpFi081ZT5sEmxhLytMBlK4vzdQxt8A70M=" alt="" />
            </div>
            <div class="ml-4">
              <div class="font-medium text-Analytics-primarytext">Fixed Deposit Receipt</div>
              <div class="text-Analytics-primarytext">Wed Jan 18 2023</div>
            </div>
          </div>
        </td>
        <td class="whitespace-nowrap px-3 py-2 text-base text-Analytics-primarytext border-y-2  border-Analytics-sidebar">
          <div class="text-green-500 font-medium">Active</div>
        </td>
        <td class="whitespace-nowrap px-3 py-2 text-sm text-Analytics-primarytext border-y-2  border-Analytics-sidebar">63779af36cb6b239c0215c8c</td>
        <td class="relative whitespace-nowrap py-2 pl-3 pr-4 text-right text-sm font-medium border-y-2 border-r-2 border-Analytics-sidebar">
          <div class="flex gap-5 items-center justify-end">
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" class="w-7 h-7 stroke-blue-500">
                <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 18L9 11.25l4.306 4.307a11.95 11.95 0 015.814-5.519l2.74-1.22m0 0l-5.94-2.28m5.94 2.28l-2.28 5.941" />
              </svg>
            </span>
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 fill-yellow-500" viewBox="0 0 24 24"><path d="M12 2c5.5 0 10 4.5 10 10s-4.5 10-10 10S2 17.5 2 12S6.5 2 12 2m0 2c-1.9 0-3.6.6-4.9 1.7l11.2 11.2c1-1.4 1.7-3.1 1.7-4.9c0-4.4-3.6-8-8-8m4.9 14.3L5.7 7.1C4.6 8.4 4 10.1 4 12c0 4.4 3.6 8 8 8c1.9 0 3.6-.6 4.9-1.7Z" /></svg>
            </span>
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 stroke-slate-400" viewBox="0 0 16 16">
                <g fill="currentColor">
                  <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z" />
                  <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z" />
                </g>
              </svg>
            </span>
            <button class="px-4 py-2 border border-Analytics-sidebar text-Analytics-iconcolor hover:bg-Analytics-iconcolor hover:text-white">View</button>
          </div>
        </td>
      </tr>
      <tr>
        <td class="whitespace-nowrap py-2 pl-4 pr-3 text-sm sm:pl-6 border-y-2 border-l-2 border-Analytics-sidebar">
          <div class="flex items-center">
            <div class="h-10 w-10 flex-shrink-0">
              <img class="h-10 w-10 rounded-sm" src="https://media.istockphoto.com/id/828088276/vector/qr-code-illustration.jpg?s=612x612&w=0&k=20&c=FnA7agr57XpFi081ZT5sEmxhLytMBlK4vzdQxt8A70M=" alt="" />
            </div>
            <div class="ml-4">
              <div class="font-medium text-Analytics-primarytext">Fixed Deposit Receipt</div>
              <div class="text-Analytics-primarytext">Wed Jan 18 2023</div>
            </div>
          </div>
        </td>
        <td class="whitespace-nowrap px-3 py-2 text-base text-Analytics-primarytext border-y-2  border-Analytics-sidebar">
          <div class="text-red-500 font-medium">Revoked</div>
          <div class="text-Analytics-primarytext">Wed Jan 18 2030</div>
        </td>
        <td class="whitespace-nowrap px-3 py-2 text-sm text-Analytics-primarytext border-y-2  border-Analytics-sidebar">63779af36cb6b239c0215c8c</td>
        <td class="relative whitespace-nowrap py-2 pl-3 pr-4 text-right text-sm font-medium border-y-2 border-r-2 border-Analytics-sidebar">
          <div class="flex gap-5 items-center justify-end">
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" class="w-7 h-7 stroke-blue-500">
                <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 18L9 11.25l4.306 4.307a11.95 11.95 0 015.814-5.519l2.74-1.22m0 0l-5.94-2.28m5.94 2.28l-2.28 5.941" />
              </svg>
            </span>
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 fill-yellow-500" viewBox="0 0 24 24"><path d="M12 2c5.5 0 10 4.5 10 10s-4.5 10-10 10S2 17.5 2 12S6.5 2 12 2m0 2c-1.9 0-3.6.6-4.9 1.7l11.2 11.2c1-1.4 1.7-3.1 1.7-4.9c0-4.4-3.6-8-8-8m4.9 14.3L5.7 7.1C4.6 8.4 4 10.1 4 12c0 4.4 3.6 8 8 8c1.9 0 3.6-.6 4.9-1.7Z" /></svg>
            </span>
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 stroke-slate-400" viewBox="0 0 16 16">
                <g fill="currentColor">
                  <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z" />
                  <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z" />
                </g>
              </svg>
            </span>
            <button class="px-4 py-2 border border-Analytics-sidebar text-Analytics-iconcolor hover:bg-Analytics-iconcolor hover:text-white">View</button>
          </div>
        </td>
      </tr>
      <tr>
        <td class="whitespace-nowrap py-2 pl-4 pr-3 text-sm sm:pl-6 border-y-2 border-l-2 border-Analytics-sidebar">
          <div class="flex items-center">
            <div class="h-10 w-10 flex-shrink-0">
              <img class="h-10 w-10 rounded-sm" src="https://media.istockphoto.com/id/828088276/vector/qr-code-illustration.jpg?s=612x612&w=0&k=20&c=FnA7agr57XpFi081ZT5sEmxhLytMBlK4vzdQxt8A70M=" alt="" />
            </div>
            <div class="ml-4">
              <div class="font-medium text-Analytics-primarytext">Fixed Deposit Receipt</div>
              <div class="text-Analytics-primarytext">Wed Jan 18 2023</div>
            </div>
          </div>
        </td>
        <td class="whitespace-nowrap px-3 py-2 text-base text-Analytics-primarytext border-y-2  border-Analytics-sidebar">
          <div class="text-green-500 font-medium">Active</div>
        </td>
        <td class="whitespace-nowrap px-3 py-2 text-sm text-Analytics-primarytext border-y-2  border-Analytics-sidebar">63779af36cb6b239c0215c8c</td>
        <td class="relative whitespace-nowrap py-2 pl-3 pr-4 text-right text-sm font-medium border-y-2 border-r-2 border-Analytics-sidebar">
          <div class="flex gap-5 items-center justify-end">
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" class="w-7 h-7 stroke-blue-500">
                <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 18L9 11.25l4.306 4.307a11.95 11.95 0 015.814-5.519l2.74-1.22m0 0l-5.94-2.28m5.94 2.28l-2.28 5.941" />
              </svg>
            </span>
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 fill-yellow-500" viewBox="0 0 24 24"><path d="M12 2c5.5 0 10 4.5 10 10s-4.5 10-10 10S2 17.5 2 12S6.5 2 12 2m0 2c-1.9 0-3.6.6-4.9 1.7l11.2 11.2c1-1.4 1.7-3.1 1.7-4.9c0-4.4-3.6-8-8-8m4.9 14.3L5.7 7.1C4.6 8.4 4 10.1 4 12c0 4.4 3.6 8 8 8c1.9 0 3.6-.6 4.9-1.7Z" /></svg>
            </span>
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 stroke-slate-400" viewBox="0 0 16 16">
                <g fill="currentColor">
                  <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z" />
                  <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z" />
                </g>
              </svg>
            </span>
            <button class="px-4 py-2 border border-Analytics-sidebar text-Analytics-iconcolor hover:bg-Analytics-iconcolor hover:text-white">View</button>
          </div>
        </td>
      </tr>
      <tr>
        <td class="whitespace-nowrap py-2 pl-4 pr-3 text-sm sm:pl-6 border-y-2 border-l-2 border-Analytics-sidebar">
          <div class="flex items-center">
            <div class="h-10 w-10 flex-shrink-0">
              <img class="h-10 w-10 rounded-sm" src="https://media.istockphoto.com/id/828088276/vector/qr-code-illustration.jpg?s=612x612&w=0&k=20&c=FnA7agr57XpFi081ZT5sEmxhLytMBlK4vzdQxt8A70M=" alt="" />
            </div>
            <div class="ml-4">
              <div class="font-medium text-Analytics-primarytext">Fixed Deposit Receipt</div>
              <div class="text-Analytics-primarytext">Wed Jan 18 2023</div>
            </div>
          </div>
        </td>
        <td class="whitespace-nowrap px-3 py-2 text-base text-Analytics-primarytext border-y-2  border-Analytics-sidebar">
          <div class="text-red-500 font-medium">Revoked</div>
          <div class="text-Analytics-primarytext">Wed Jan 18 2030</div>
        </td>
        <td class="whitespace-nowrap px-3 py-2 text-sm text-Analytics-primarytext border-y-2  border-Analytics-sidebar">63779af36cb6b239c0215c8c</td>
        <td class="relative whitespace-nowrap py-2 pl-3 pr-4 text-right text-sm font-medium border-y-2 border-r-2 border-Analytics-sidebar">
          <div class="flex gap-5 items-center justify-end">
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" class="w-7 h-7 stroke-blue-500">
                <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 18L9 11.25l4.306 4.307a11.95 11.95 0 015.814-5.519l2.74-1.22m0 0l-5.94-2.28m5.94 2.28l-2.28 5.941" />
              </svg>
            </span>
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 fill-yellow-500" viewBox="0 0 24 24"><path d="M12 2c5.5 0 10 4.5 10 10s-4.5 10-10 10S2 17.5 2 12S6.5 2 12 2m0 2c-1.9 0-3.6.6-4.9 1.7l11.2 11.2c1-1.4 1.7-3.1 1.7-4.9c0-4.4-3.6-8-8-8m4.9 14.3L5.7 7.1C4.6 8.4 4 10.1 4 12c0 4.4 3.6 8 8 8c1.9 0 3.6-.6 4.9-1.7Z" /></svg>
            </span>
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 stroke-slate-400" viewBox="0 0 16 16">
                <g fill="currentColor">
                  <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z" />
                  <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z" />
                </g>
              </svg>
            </span>
            <button class="px-4 py-2 border border-Analytics-sidebar text-Analytics-iconcolor hover:bg-Analytics-iconcolor hover:text-white">View</button>
          </div>
        </td>
      </tr>
      <tr>
        <td class="whitespace-nowrap py-2 pl-4 pr-3 text-sm sm:pl-6 border-y-2 border-l-2 border-Analytics-sidebar">
          <div class="flex items-center">
            <div class="h-10 w-10 flex-shrink-0">
              <img class="h-10 w-10 rounded-sm" src="https://media.istockphoto.com/id/828088276/vector/qr-code-illustration.jpg?s=612x612&w=0&k=20&c=FnA7agr57XpFi081ZT5sEmxhLytMBlK4vzdQxt8A70M=" alt="" />
            </div>
            <div class="ml-4">
              <div class="font-medium text-Analytics-primarytext">Fixed Deposit Receipt</div>
              <div class="text-Analytics-primarytext">Wed Jan 18 2023</div>
            </div>
          </div>
        </td>
        <td class="whitespace-nowrap px-3 py-2 text-base text-Analytics-primarytext border-y-2  border-Analytics-sidebar">
          <div class="text-green-500 font-medium">Active</div>
        </td>
        <td class="whitespace-nowrap px-3 py-2 text-sm text-Analytics-primarytext border-y-2  border-Analytics-sidebar">63779af36cb6b239c0215c8c</td>
        <td class="relative whitespace-nowrap py-2 pl-3 pr-4 text-right text-sm font-medium border-y-2 border-r-2 border-Analytics-sidebar">
          <div class="flex gap-5 items-center justify-end">
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" class="w-7 h-7 stroke-blue-500">
                <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 18L9 11.25l4.306 4.307a11.95 11.95 0 015.814-5.519l2.74-1.22m0 0l-5.94-2.28m5.94 2.28l-2.28 5.941" />
              </svg>
            </span>
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 fill-yellow-500" viewBox="0 0 24 24"><path d="M12 2c5.5 0 10 4.5 10 10s-4.5 10-10 10S2 17.5 2 12S6.5 2 12 2m0 2c-1.9 0-3.6.6-4.9 1.7l11.2 11.2c1-1.4 1.7-3.1 1.7-4.9c0-4.4-3.6-8-8-8m4.9 14.3L5.7 7.1C4.6 8.4 4 10.1 4 12c0 4.4 3.6 8 8 8c1.9 0 3.6-.6 4.9-1.7Z" /></svg>
            </span>
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 stroke-slate-400" viewBox="0 0 16 16">
                <g fill="currentColor">
                  <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z" />
                  <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z" />
                </g>
              </svg>
            </span>
            <button class="px-4 py-2 border border-Analytics-sidebar text-Analytics-iconcolor hover:bg-Analytics-iconcolor hover:text-white">View</button>
          </div>
        </td>
      </tr>
      <tr>
        <td class="whitespace-nowrap py-2 pl-4 pr-3 text-sm sm:pl-6 border-y-2 border-l-2 border-Analytics-sidebar">
          <div class="flex items-center">
            <div class="h-10 w-10 flex-shrink-0">
              <img class="h-10 w-10 rounded-sm" src="https://media.istockphoto.com/id/828088276/vector/qr-code-illustration.jpg?s=612x612&w=0&k=20&c=FnA7agr57XpFi081ZT5sEmxhLytMBlK4vzdQxt8A70M=" alt="" />
            </div>
            <div class="ml-4">
              <div class="font-medium text-Analytics-primarytext">Fixed Deposit Receipt</div>
              <div class="text-Analytics-primarytext">Wed Jan 18 2023</div>
            </div>
          </div>
        </td>
        <td class="whitespace-nowrap px-3 py-2 text-base text-Analytics-primarytext border-y-2  border-Analytics-sidebar">
          <div class="text-red-500 font-medium">Revoked</div>
          <div class="text-Analytics-primarytext">Wed Jan 18 2030</div>
        </td>
        <td class="whitespace-nowrap px-3 py-2 text-sm text-Analytics-primarytext border-y-2  border-Analytics-sidebar">63779af36cb6b239c0215c8c</td>
        <td class="relative whitespace-nowrap py-2 pl-3 pr-4 text-right text-sm font-medium border-y-2 border-r-2 border-Analytics-sidebar">
          <div class="flex gap-5 items-center justify-end">
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" class="w-7 h-7 stroke-blue-500">
                <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 18L9 11.25l4.306 4.307a11.95 11.95 0 015.814-5.519l2.74-1.22m0 0l-5.94-2.28m5.94 2.28l-2.28 5.941" />
              </svg>
            </span>
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 fill-yellow-500" viewBox="0 0 24 24"><path d="M12 2c5.5 0 10 4.5 10 10s-4.5 10-10 10S2 17.5 2 12S6.5 2 12 2m0 2c-1.9 0-3.6.6-4.9 1.7l11.2 11.2c1-1.4 1.7-3.1 1.7-4.9c0-4.4-3.6-8-8-8m4.9 14.3L5.7 7.1C4.6 8.4 4 10.1 4 12c0 4.4 3.6 8 8 8c1.9 0 3.6-.6 4.9-1.7Z" /></svg>
            </span>
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 stroke-slate-400" viewBox="0 0 16 16">
                <g fill="currentColor">
                  <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z" />
                  <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z" />
                </g>
              </svg>
            </span>
            <button class="px-4 py-2 border border-Analytics-sidebar text-Analytics-iconcolor hover:bg-Analytics-iconcolor hover:text-white">View</button>
          </div>
        </td>
      </tr>
      <tr>
        <td class="whitespace-nowrap py-2 pl-4 pr-3 text-sm sm:pl-6 border-y-2 border-l-2 border-Analytics-sidebar">
          <div class="flex items-center">
            <div class="h-10 w-10 flex-shrink-0">
              <img class="h-10 w-10 rounded-sm" src="https://media.istockphoto.com/id/828088276/vector/qr-code-illustration.jpg?s=612x612&w=0&k=20&c=FnA7agr57XpFi081ZT5sEmxhLytMBlK4vzdQxt8A70M=" alt="" />
            </div>
            <div class="ml-4">
              <div class="font-medium text-Analytics-primarytext">Fixed Deposit Receipt</div>
              <div class="text-Analytics-primarytext">Wed Jan 18 2023</div>
            </div>
          </div>
        </td>
        <td class="whitespace-nowrap px-3 py-2 text-base text-Analytics-primarytext border-y-2  border-Analytics-sidebar">
          <div class="text-green-500 font-medium">Active</div>
        </td>
        <td class="whitespace-nowrap px-3 py-2 text-sm text-Analytics-primarytext border-y-2  border-Analytics-sidebar">63779af36cb6b239c0215c8c</td>
        <td class="relative whitespace-nowrap py-2 pl-3 pr-4 text-right text-sm font-medium border-y-2 border-r-2 border-Analytics-sidebar">
          <div class="flex gap-5 items-center justify-end">
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" class="w-7 h-7 stroke-blue-500">
                <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 18L9 11.25l4.306 4.307a11.95 11.95 0 015.814-5.519l2.74-1.22m0 0l-5.94-2.28m5.94 2.28l-2.28 5.941" />
              </svg>
            </span>
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 fill-yellow-500" viewBox="0 0 24 24"><path d="M12 2c5.5 0 10 4.5 10 10s-4.5 10-10 10S2 17.5 2 12S6.5 2 12 2m0 2c-1.9 0-3.6.6-4.9 1.7l11.2 11.2c1-1.4 1.7-3.1 1.7-4.9c0-4.4-3.6-8-8-8m4.9 14.3L5.7 7.1C4.6 8.4 4 10.1 4 12c0 4.4 3.6 8 8 8c1.9 0 3.6-.6 4.9-1.7Z" /></svg>
            </span>
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 stroke-slate-400" viewBox="0 0 16 16">
                <g fill="currentColor">
                  <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z" />
                  <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z" />
                </g>
              </svg>
            </span>
            <button class="px-4 py-2 border border-Analytics-sidebar text-Analytics-iconcolor hover:bg-Analytics-iconcolor hover:text-white">View</button>
          </div>
        </td>
      </tr>
      <!-- <tr>
        <td class="whitespace-nowrap py-2 pl-4 pr-3 text-sm sm:pl-6 border-y-2 border-l-2 border-Analytics-sidebar">
          <div class="flex items-center">
            <div class="h-10 w-10 flex-shrink-0">
              <img class="h-10 w-10 rounded-sm" src="https://media.istockphoto.com/id/828088276/vector/qr-code-illustration.jpg?s=612x612&w=0&k=20&c=FnA7agr57XpFi081ZT5sEmxhLytMBlK4vzdQxt8A70M=" alt="" />
            </div>
            <div class="ml-4">
              <div class="font-medium text-Analytics-primarytext">Fixed Deposit Receipt</div>
              <div class="text-Analytics-primarytext">Wed Jan 18 2023</div>
            </div>
          </div>
        </td>
        <td class="whitespace-nowrap px-3 py-2 text-base text-Analytics-primarytext border-y-2  border-Analytics-sidebar">
          <div class="text-red-500 font-medium">Revoked</div>
          <div class="text-Analytics-primarytext">Wed Jan 18 2030</div>
        </td>
        <td class="whitespace-nowrap px-3 py-2 text-sm text-Analytics-primarytext border-y-2  border-Analytics-sidebar">63779af36cb6b239c0215c8c</td>
        <td class="relative whitespace-nowrap py-2 pl-3 pr-4 text-right text-sm font-medium border-y-2 border-r-2 border-Analytics-sidebar">
          <div class="flex gap-5 items-center justify-end">
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" class="w-7 h-7 stroke-blue-500">
                <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 18L9 11.25l4.306 4.307a11.95 11.95 0 015.814-5.519l2.74-1.22m0 0l-5.94-2.28m5.94 2.28l-2.28 5.941" />
              </svg>
            </span>
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 fill-yellow-500" viewBox="0 0 24 24"><path d="M12 2c5.5 0 10 4.5 10 10s-4.5 10-10 10S2 17.5 2 12S6.5 2 12 2m0 2c-1.9 0-3.6.6-4.9 1.7l11.2 11.2c1-1.4 1.7-3.1 1.7-4.9c0-4.4-3.6-8-8-8m4.9 14.3L5.7 7.1C4.6 8.4 4 10.1 4 12c0 4.4 3.6 8 8 8c1.9 0 3.6-.6 4.9-1.7Z" /></svg>
            </span>
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 stroke-slate-400" viewBox="0 0 16 16">
                <g fill="currentColor">
                  <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z" />
                  <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z" />
                </g>
              </svg>
            </span>
            <button class="px-4 py-2 border border-Analytics-sidebar text-Analytics-iconcolor hover:bg-Analytics-iconcolor hover:text-white">View</button>
          </div>
        </td>
      </tr>
      <tr>
        <td class="whitespace-nowrap py-2 pl-4 pr-3 text-sm sm:pl-6 border-y-2 border-l-2 border-Analytics-sidebar">
          <div class="flex items-center">
            <div class="h-10 w-10 flex-shrink-0">
              <img class="h-10 w-10 rounded-sm" src="https://media.istockphoto.com/id/828088276/vector/qr-code-illustration.jpg?s=612x612&w=0&k=20&c=FnA7agr57XpFi081ZT5sEmxhLytMBlK4vzdQxt8A70M=" alt="" />
            </div>
            <div class="ml-4">
              <div class="font-medium text-Analytics-primarytext">Fixed Deposit Receipt</div>
              <div class="text-Analytics-primarytext">Wed Jan 18 2023</div>
            </div>
          </div>
        </td>
        <td class="whitespace-nowrap px-3 py-2 text-base text-Analytics-primarytext border-y-2  border-Analytics-sidebar">
          <div class="text-green-500 font-medium">Active</div>
        </td>
        <td class="whitespace-nowrap px-3 py-2 text-sm text-Analytics-primarytext border-y-2  border-Analytics-sidebar">63779af36cb6b239c0215c8c</td>
        <td class="relative whitespace-nowrap py-2 pl-3 pr-4 text-right text-sm font-medium border-y-2 border-r-2 border-Analytics-sidebar">
          <div class="flex gap-5 items-center justify-end">
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" class="w-7 h-7 stroke-blue-500">
                <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 18L9 11.25l4.306 4.307a11.95 11.95 0 015.814-5.519l2.74-1.22m0 0l-5.94-2.28m5.94 2.28l-2.28 5.941" />
              </svg>
            </span>
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 fill-yellow-500" viewBox="0 0 24 24"><path d="M12 2c5.5 0 10 4.5 10 10s-4.5 10-10 10S2 17.5 2 12S6.5 2 12 2m0 2c-1.9 0-3.6.6-4.9 1.7l11.2 11.2c1-1.4 1.7-3.1 1.7-4.9c0-4.4-3.6-8-8-8m4.9 14.3L5.7 7.1C4.6 8.4 4 10.1 4 12c0 4.4 3.6 8 8 8c1.9 0 3.6-.6 4.9-1.7Z" /></svg>
            </span>
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 stroke-slate-400" viewBox="0 0 16 16">
                <g fill="currentColor">
                  <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z" />
                  <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z" />
                </g>
              </svg>
            </span>
            <button class="px-4 py-2 border border-Analytics-sidebar text-Analytics-iconcolor hover:bg-Analytics-iconcolor hover:text-white">View</button>
          </div>
        </td>
      </tr> -->
    </tbody>
  </table>
</div>
