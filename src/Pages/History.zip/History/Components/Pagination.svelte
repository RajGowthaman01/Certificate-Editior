<div class="absolute bottom-0 flex w-full border-t-Analytics-sidebar">
  <div class="flex items-center w-full  border border-Analytics-sidebar bg-transparent px-4 py-3 sm:px-6">
    <div class="hidden sm:flex sm:flex-1 sm:items-center sm:justify-between">
      <div class="inline-flex justify-center items-center gap-3 ">
        <h1 class="text-sm font-medium tracking-wide text-white">Show</h1>
        <select name="" id="" class="text-sm font-medium tracking-wide text-white bg-transparent border-none rounded-md">
          <option value="10" class="text-Analytics-primary">10</option>
          <option value="100" class="text-Analytics-primary">100</option>
          <option value="500" class="text-Analytics-primary">500</option>
        </select>
        <h1 class="text-sm font-medium tracking-wide text-white">Entries</h1>
      </div>

      <div>
        <nav class="isolate inline-flex -space-x-px" aria-label="Pagination">
          <a href="/" class="relative inline-flex items-center border border-Analytics-sidebar bg-transparent px-2 py-2 text-sm font-medium text-gray-500 hover:bg-Analytics-sidebar focus:z-20">
            <span class="sr-only">Previous</span>
            <!-- Heroicon name: mini/chevron-left -->
            <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
              <path fill-rule="evenodd" d="M12.79 5.23a.75.75 0 01-.02 1.06L8.832 10l3.938 3.71a.75.75 0 11-1.04 1.08l-4.5-4.25a.75.75 0 010-1.08l4.5-4.25a.75.75 0 011.06.02z" clip-rule="evenodd" />
            </svg>
          </a>
          <!-- Current: "z-10 bg-indigo-50 border-indigo-500 text-indigo-600", Default: "bg-transparent border-Analytics-sidebar text-gray-500 hover:bg-Analytics-sidebar" -->
          <a href="/" aria-current="page" class="relative z-10 inline-flex items-center border border-Analytics-primarytext bg-Analytics-secondary px-4 py-2 text-sm font-medium text-indigo-600 focus:z-20">1</a>
          <a href="/" class="relative inline-flex items-center border border-Analytics-sidebar bg-transparent px-4 py-2 text-sm font-medium text-gray-500 hover:bg-Analytics-sidebar focus:z-20">2</a>
          <a href="/" class="relative hidden items-center border border-Analytics-sidebar bg-transparent px-4 py-2 text-sm font-medium text-gray-500 hover:bg-Analytics-sidebar focus:z-20 md:inline-flex">3</a>
          <span class="relative inline-flex items-center border border-Analytics-sidebar bg-transparent px-4 py-2 text-sm font-medium text-gray-700">...</span>
          <a href="/" class="relative hidden items-center border border-Analytics-sidebar bg-transparent px-4 py-2 text-sm font-medium text-gray-500 hover:bg-Analytics-sidebar focus:z-20 md:inline-flex">8</a>
          <a href="/" class="relative inline-flex items-center border border-Analytics-sidebar bg-transparent px-4 py-2 text-sm font-medium text-gray-500 hover:bg-Analytics-sidebar focus:z-20">9</a>
          <a href="/" class="relative inline-flex items-center border border-Analytics-sidebar bg-transparent px-4 py-2 text-sm font-medium text-gray-500 hover:bg-Analytics-sidebar focus:z-20">10</a>
          <a href="/" class="relative inline-flex items-center border border-Analytics-sidebar bg-transparent px-2 py-2 text-sm font-medium text-gray-500 hover:bg-Analytics-sidebar focus:z-20">
            <span class="sr-only">Next</span>
            <!-- Heroicon name: mini/chevron-right -->
            <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
              <path fill-rule="evenodd" d="M7.21 14.77a.75.75 0 01.02-1.06L11.168 10 7.23 6.29a.75.75 0 111.04-1.08l4.5 4.25a.75.75 0 010 1.08l-4.5 4.25a.75.75 0 01-1.06-.02z" clip-rule="evenodd" />
            </svg>
          </a>
        </nav>
      </div>
    </div>
  </div>
</div>
