<!-- Component Start  -->
<div class="flex flex-col w-full border-t border-Analytics-sidebar text-sm text-Analytics-primarytext">
  <div class="flex flex-shrink-0 bg-Analytics-sidebar text-white">
    <div class="flex items-center flex-grow w-0 h-10 px-2 text-base"><span>Document Details</span></div>
    <div class="flex items-center flex-grow w-0 h-10 px-2 text-base"><span>Status</span></div>
    <div class="flex items-center flex-grow w-0 h-10 px-2 text-base"><span>Document Id</span></div>
    <div class="flex items-center flex-grow w-0 h-10 px-2 text-base"><span>Actions</span></div>
  </div>
  <div class="overflow-auto h-[520px]">
    <div class="flex flex-shrink-0 pt-2">
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b border-l border-t border-Analytics-sidebar">
        <span>
          <div class="flex items-center">
            <div class="h-10 w-10 flex-shrink-0">
              <img class="h-10 w-10 rounded-sm" src="https://media.istockphoto.com/id/828088276/vector/qr-code-illustration.jpg?s=612x612&w=0&k=20&c=FnA7agr57XpFi081ZT5sEmxhLytMBlK4vzdQxt8A70M=" alt="" />
            </div>
            <div class="ml-4">
              <div class="font-medium text-Analytics-primarytext">Fixed Deposit Receipt</div>
              <div class="text-Analytics-primarytext">Wed Jan 18 2023</div>
            </div>
          </div>
        </span>
      </div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-t border-Analytics-sidebar">
        <span class="inline-flex gap-2 justify-center items-center">
          <div>
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-6 w-6 stroke-green-600">
              <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <div class="text-green-500 font-medium">Active</div>
        </span>
      </div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-t border-Analytics-sidebar"><span>63779af36cb6b239c0215c8c</span></div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-t border-r border-Analytics-sidebar">
        <span>
          <div class="flex gap-2 items-center justify-end">
            <button class="py-2 px-3 border border-Analytics-sidebar text-Analytics-iconcolor hover:bg-Analytics-iconcolor hover:text-white">Analytics</button>
            <button class="py-2 px-3 border border-Analytics-sidebar text-yellow-500 hover:bg-yellow-600 hover:text-white">Revoke</button>
            <button class="py-2 px-3 border border-Analytics-sidebar text-green-500 hover:bg-green-600 hover:text-white">Aliases</button>
          </div>
        </span>
      </div>
    </div>
    <div class="flex flex-shrink-0 pt-2">
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b border-l border-t border-Analytics-sidebar">
        <span>
          <div class="flex items-center">
            <div class="h-10 w-10 flex-shrink-0">
              <img class="h-10 w-10 rounded-sm" src="https://media.istockphoto.com/id/828088276/vector/qr-code-illustration.jpg?s=612x612&w=0&k=20&c=FnA7agr57XpFi081ZT5sEmxhLytMBlK4vzdQxt8A70M=" alt="" />
            </div>
            <div class="ml-4">
              <div class="font-medium text-Analytics-primarytext">Fixed Deposit Receipt</div>
              <div class="text-Analytics-primarytext">Wed Jan 18 2023</div>
            </div>
          </div>
        </span>
      </div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-t border-Analytics-sidebar">
        <span />
        <span class="inline-flex gap-2 justify-center items-center">
          <div>
            <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 fill-red-500" viewBox="0 0 24 24"><path d="M12 2c5.5 0 10 4.5 10 10s-4.5 10-10 10S2 17.5 2 12S6.5 2 12 2m0 2c-1.9 0-3.6.6-4.9 1.7l11.2 11.2c1-1.4 1.7-3.1 1.7-4.9c0-4.4-3.6-8-8-8m4.9 14.3L5.7 7.1C4.6 8.4 4 10.1 4 12c0 4.4 3.6 8 8 8c1.9 0 3.6-.6 4.9-1.7Z" /></svg>
          </div>
          <div>
            <div class="text-red-500 font-medium">Revoke</div>
            <div class="font-medium">Wed Jan 18 2030</div>
          </div>
        </span>
      </div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-t border-Analytics-sidebar"><span>63779af36cb6b239c0215c8c</span></div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-r border-t border-Analytics-sidebar">
        <span>
          <div class="flex gap-2 items-center justify-end">
            <button class="py-2 px-3 border border-Analytics-sidebar text-Analytics-iconcolor hover:bg-Analytics-iconcolor hover:text-white">Analytics</button>
            <button class="py-2 px-3 border border-Analytics-sidebar text-yellow-500 hover:bg-yellow-600 hover:text-white">Revoke</button>
            <button class="py-2 px-3 border border-Analytics-sidebar text-green-500 hover:bg-green-600 hover:text-white">Aliases</button>
          </div>
        </span>
      </div>
    </div>
    <div class="flex flex-shrink-0 pt-2">
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b border-l  border-t border-Analytics-sidebar">
        <span>
          <div class="flex items-center">
            <div class="h-10 w-10 flex-shrink-0">
              <img class="h-10 w-10 rounded-sm" src="https://media.istockphoto.com/id/828088276/vector/qr-code-illustration.jpg?s=612x612&w=0&k=20&c=FnA7agr57XpFi081ZT5sEmxhLytMBlK4vzdQxt8A70M=" alt="" />
            </div>
            <div class="ml-4">
              <div class="font-medium text-Analytics-primarytext">Fixed Deposit Receipt</div>
              <div class="text-Analytics-primarytext">Wed Jan 18 2023</div>
            </div>
          </div>
        </span>
      </div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-t border-Analytics-sidebar">
        <span class="inline-flex gap-2 justify-center items-center">
          <div>
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-6 w-6 stroke-green-600">
              <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <div class="text-green-500 font-medium">Active</div>
        </span>
      </div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-t border-Analytics-sidebar"><span>63779af36cb6b239c0215c8c</span></div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-t border-r border-Analytics-sidebar">
        <span>
          <div class="flex gap-2 items-center justify-end">
            <button class="py-2 px-3 border border-Analytics-sidebar text-Analytics-iconcolor hover:bg-Analytics-iconcolor hover:text-white">Analytics</button>
            <button class="py-2 px-3 border border-Analytics-sidebar text-yellow-500 hover:bg-yellow-600 hover:text-white">Revoke</button>
            <button class="py-2 px-3 border border-Analytics-sidebar text-green-500 hover:bg-green-600 hover:text-white">Aliases</button>
          </div>
        </span>
      </div>
    </div>
    <div class="flex flex-shrink-0 pt-2">
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b border-l border-t border-Analytics-sidebar">
        <span>
          <div class="flex items-center">
            <div class="h-10 w-10 flex-shrink-0">
              <img class="h-10 w-10 rounded-sm" src="https://media.istockphoto.com/id/828088276/vector/qr-code-illustration.jpg?s=612x612&w=0&k=20&c=FnA7agr57XpFi081ZT5sEmxhLytMBlK4vzdQxt8A70M=" alt="" />
            </div>
            <div class="ml-4">
              <div class="font-medium text-Analytics-primarytext">Fixed Deposit Receipt</div>
              <div class="text-Analytics-primarytext">Wed Jan 18 2023</div>
            </div>
          </div>
        </span>
      </div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-t border-Analytics-sidebar">
        <span class="inline-flex gap-2 justify-center items-center">
          <div>
            <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 fill-red-500" viewBox="0 0 24 24"><path d="M12 2c5.5 0 10 4.5 10 10s-4.5 10-10 10S2 17.5 2 12S6.5 2 12 2m0 2c-1.9 0-3.6.6-4.9 1.7l11.2 11.2c1-1.4 1.7-3.1 1.7-4.9c0-4.4-3.6-8-8-8m4.9 14.3L5.7 7.1C4.6 8.4 4 10.1 4 12c0 4.4 3.6 8 8 8c1.9 0 3.6-.6 4.9-1.7Z" /></svg>
          </div>
          <div>
            <div class="text-red-500 font-medium">Revoke</div>
            <div class="font-medium">Wed Jan 18 2030</div>
          </div>
        </span>
      </div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-t border-Analytics-sidebar"><span>63779af36cb6b239c0215c8c</span></div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-r border-t border-Analytics-sidebar">
        <span>
          <div class="flex gap-2 items-center justify-end">
            <button class="py-2 px-3 border border-Analytics-sidebar text-Analytics-iconcolor hover:bg-Analytics-iconcolor hover:text-white">Analytics</button>
            <button class="py-2 px-3 border border-Analytics-sidebar text-yellow-500 hover:bg-yellow-600 hover:text-white">Revoke</button>
            <button class="py-2 px-3 border border-Analytics-sidebar text-green-500 hover:bg-green-600 hover:text-white">Aliases</button>
          </div>
        </span>
      </div>
    </div>
    <div class="flex flex-shrink-0 pt-2">
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b border-l border-t border-Analytics-sidebar">
        <span>
          <div class="flex items-center">
            <div class="h-10 w-10 flex-shrink-0">
              <img class="h-10 w-10 rounded-sm" src="https://media.istockphoto.com/id/828088276/vector/qr-code-illustration.jpg?s=612x612&w=0&k=20&c=FnA7agr57XpFi081ZT5sEmxhLytMBlK4vzdQxt8A70M=" alt="" />
            </div>
            <div class="ml-4">
              <div class="font-medium text-Analytics-primarytext">Fixed Deposit Receipt</div>
              <div class="text-Analytics-primarytext">Wed Jan 18 2023</div>
            </div>
          </div>
        </span>
      </div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-t border-Analytics-sidebar">
        <span class="inline-flex gap-2 justify-center items-center">
          <div>
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-6 w-6 stroke-green-600">
              <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <div class="text-green-500 font-medium">Active</div>
        </span>
      </div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-t border-Analytics-sidebar"><span>63779af36cb6b239c0215c8c</span></div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-t border-r border-Analytics-sidebar">
        <span>
          <div class="flex gap-2 items-center justify-end">
            <button class="py-2 px-3 border border-Analytics-sidebar text-Analytics-iconcolor hover:bg-Analytics-iconcolor hover:text-white">Analytics</button>
            <button class="py-2 px-3 border border-Analytics-sidebar text-yellow-500 hover:bg-yellow-600 hover:text-white">Revoke</button>
            <button class="py-2 px-3 border border-Analytics-sidebar text-green-500 hover:bg-green-600 hover:text-white">Aliases</button>
          </div>
        </span>
      </div>
    </div>
    <div class="flex flex-shrink-0 pt-2">
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b border-l border-t border-Analytics-sidebar">
        <span>
          <div class="flex items-center">
            <div class="h-10 w-10 flex-shrink-0">
              <img class="h-10 w-10 rounded-sm" src="https://media.istockphoto.com/id/828088276/vector/qr-code-illustration.jpg?s=612x612&w=0&k=20&c=FnA7agr57XpFi081ZT5sEmxhLytMBlK4vzdQxt8A70M=" alt="" />
            </div>
            <div class="ml-4">
              <div class="font-medium text-Analytics-primarytext">Fixed Deposit Receipt</div>
              <div class="text-Analytics-primarytext">Wed Jan 18 2023</div>
            </div>
          </div>
        </span>
      </div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-t border-Analytics-sidebar">
        <span class="inline-flex gap-2 justify-center items-center">
          <div>
            <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 fill-red-500" viewBox="0 0 24 24"><path d="M12 2c5.5 0 10 4.5 10 10s-4.5 10-10 10S2 17.5 2 12S6.5 2 12 2m0 2c-1.9 0-3.6.6-4.9 1.7l11.2 11.2c1-1.4 1.7-3.1 1.7-4.9c0-4.4-3.6-8-8-8m4.9 14.3L5.7 7.1C4.6 8.4 4 10.1 4 12c0 4.4 3.6 8 8 8c1.9 0 3.6-.6 4.9-1.7Z" /></svg>
          </div>
          <div>
            <div class="text-red-500 font-medium">Revoke</div>
            <div class="font-medium">Wed Jan 18 2030</div>
          </div>
        </span>
      </div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-t border-Analytics-sidebar"><span>63779af36cb6b239c0215c8c</span></div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-r border-t border-Analytics-sidebar">
        <span>
          <div class="flex gap-2 items-center justify-end">
            <button class="py-2 px-3 border border-Analytics-sidebar text-Analytics-iconcolor hover:bg-Analytics-iconcolor hover:text-white">Analytics</button>
            <button class="py-2 px-3 border border-Analytics-sidebar text-yellow-500 hover:bg-yellow-600 hover:text-white">Revoke</button>
            <button class="py-2 px-3 border border-Analytics-sidebar text-green-500 hover:bg-green-600 hover:text-white">Aliases</button>
          </div>
        </span>
      </div>
    </div>
    <div class="flex flex-shrink-0 pt-2">
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b border-l border-t border-Analytics-sidebar">
        <span>
          <div class="flex items-center">
            <div class="h-10 w-10 flex-shrink-0">
              <img class="h-10 w-10 rounded-sm" src="https://media.istockphoto.com/id/828088276/vector/qr-code-illustration.jpg?s=612x612&w=0&k=20&c=FnA7agr57XpFi081ZT5sEmxhLytMBlK4vzdQxt8A70M=" alt="" />
            </div>
            <div class="ml-4">
              <div class="font-medium text-Analytics-primarytext">Fixed Deposit Receipt</div>
              <div class="text-Analytics-primarytext">Wed Jan 18 2023</div>
            </div>
          </div>
        </span>
      </div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-t border-Analytics-sidebar">
        <span class="inline-flex gap-2 justify-center items-center">
          <div>
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-6 w-6 stroke-green-600">
              <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <div class="text-green-500 font-medium">Active</div>
        </span>
      </div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-t border-Analytics-sidebar"><span>63779af36cb6b239c0215c8c</span></div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-t border-r border-Analytics-sidebar">
        <span>
          <div class="flex gap-2 items-center justify-end">
            <button class="py-2 px-3 border border-Analytics-sidebar text-Analytics-iconcolor hover:bg-Analytics-iconcolor hover:text-white">Analytics</button>
            <button class="py-2 px-3 border border-Analytics-sidebar text-yellow-500 hover:bg-yellow-600 hover:text-white">Revoke</button>
            <button class="py-2 px-3 border border-Analytics-sidebar text-green-500 hover:bg-green-600 hover:text-white">Aliases</button>
          </div>
        </span>
      </div>
    </div>
    <div class="flex flex-shrink-0 pt-2">
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b border-l border-t border-Analytics-sidebar">
        <span>
          <div class="flex items-center">
            <div class="h-10 w-10 flex-shrink-0">
              <img class="h-10 w-10 rounded-sm" src="https://media.istockphoto.com/id/828088276/vector/qr-code-illustration.jpg?s=612x612&w=0&k=20&c=FnA7agr57XpFi081ZT5sEmxhLytMBlK4vzdQxt8A70M=" alt="" />
            </div>
            <div class="ml-4">
              <div class="font-medium text-Analytics-primarytext">Fixed Deposit Receipt</div>
              <div class="text-Analytics-primarytext">Wed Jan 18 2023</div>
            </div>
          </div>
        </span>
      </div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-t border-Analytics-sidebar">
        <span class="inline-flex gap-2 justify-center items-center">
          <div>
            <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 fill-red-500" viewBox="0 0 24 24"><path d="M12 2c5.5 0 10 4.5 10 10s-4.5 10-10 10S2 17.5 2 12S6.5 2 12 2m0 2c-1.9 0-3.6.6-4.9 1.7l11.2 11.2c1-1.4 1.7-3.1 1.7-4.9c0-4.4-3.6-8-8-8m4.9 14.3L5.7 7.1C4.6 8.4 4 10.1 4 12c0 4.4 3.6 8 8 8c1.9 0 3.6-.6 4.9-1.7Z" /></svg>
          </div>
          <div>
            <div class="text-red-500 font-medium">Revoke</div>
            <div class="font-medium">Wed Jan 18 2030</div>
          </div>
        </span>
      </div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-t border-Analytics-sidebar"><span>63779af36cb6b239c0215c8c</span></div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-r border-t border-Analytics-sidebar">
        <span>
          <div class="flex gap-2 items-center justify-end">
            <button class="py-2 px-3 border border-Analytics-sidebar text-Analytics-iconcolor hover:bg-Analytics-iconcolor hover:text-white">Analytics</button>
            <button class="py-2 px-3 border border-Analytics-sidebar text-yellow-500 hover:bg-yellow-600 hover:text-white">Revoke</button>
            <button class="py-2 px-3 border border-Analytics-sidebar text-green-500 hover:bg-green-600 hover:text-white">Aliases</button>
          </div>
        </span>
      </div>
    </div>
    <div class="flex flex-shrink-0 pt-2">
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b border-l border-t border-Analytics-sidebar">
        <span>
          <div class="flex items-center">
            <div class="h-10 w-10 flex-shrink-0">
              <img class="h-10 w-10 rounded-sm" src="https://media.istockphoto.com/id/828088276/vector/qr-code-illustration.jpg?s=612x612&w=0&k=20&c=FnA7agr57XpFi081ZT5sEmxhLytMBlK4vzdQxt8A70M=" alt="" />
            </div>
            <div class="ml-4">
              <div class="font-medium text-Analytics-primarytext">Fixed Deposit Receipt</div>
              <div class="text-Analytics-primarytext">Wed Jan 18 2023</div>
            </div>
          </div>
        </span>
      </div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-t border-Analytics-sidebar">
        <span class="inline-flex gap-2 justify-center items-center">
          <div>
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-6 w-6 stroke-green-600">
              <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <div class="text-green-500 font-medium">Active</div>
        </span>
      </div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-t border-Analytics-sidebar"><span>63779af36cb6b239c0215c8c</span></div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-t border-r border-Analytics-sidebar">
        <span>
          <div class="flex gap-2 items-center justify-end">
            <button class="py-2 px-3 border border-Analytics-sidebar text-Analytics-iconcolor hover:bg-Analytics-iconcolor hover:text-white">Analytics</button>
            <button class="py-2 px-3 border border-Analytics-sidebar text-yellow-500 hover:bg-yellow-600 hover:text-white">Revoke</button>
            <button class="py-2 px-3 border border-Analytics-sidebar text-green-500 hover:bg-green-600 hover:text-white">Aliases</button>
          </div>
        </span>
      </div>
    </div>
    <div class="flex flex-shrink-0 pt-2">
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b border-l border-t border-Analytics-sidebar">
        <span>
          <div class="flex items-center">
            <div class="h-10 w-10 flex-shrink-0">
              <img class="h-10 w-10 rounded-sm" src="https://media.istockphoto.com/id/828088276/vector/qr-code-illustration.jpg?s=612x612&w=0&k=20&c=FnA7agr57XpFi081ZT5sEmxhLytMBlK4vzdQxt8A70M=" alt="" />
            </div>
            <div class="ml-4">
              <div class="font-medium text-Analytics-primarytext">Fixed Deposit Receipt</div>
              <div class="text-Analytics-primarytext">Wed Jan 18 2023</div>
            </div>
          </div>
        </span>
      </div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-t border-Analytics-sidebar">
        <span class="inline-flex gap-2 justify-center items-center">
          <div>
            <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 fill-red-500" viewBox="0 0 24 24"><path d="M12 2c5.5 0 10 4.5 10 10s-4.5 10-10 10S2 17.5 2 12S6.5 2 12 2m0 2c-1.9 0-3.6.6-4.9 1.7l11.2 11.2c1-1.4 1.7-3.1 1.7-4.9c0-4.4-3.6-8-8-8m4.9 14.3L5.7 7.1C4.6 8.4 4 10.1 4 12c0 4.4 3.6 8 8 8c1.9 0 3.6-.6 4.9-1.7Z" /></svg>
          </div>
          <div>
            <div class="text-red-500 font-medium">Revoke</div>
            <div class="font-medium">Wed Jan 18 2030</div>
          </div>
        </span>
      </div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-t border-Analytics-sidebar"><span>63779af36cb6b239c0215c8c</span></div>
      <div class="flex items-center flex-grow w-0 h-16 px-2 border-b  border-r border-t border-Analytics-sidebar">
        <span>
          <div class="flex gap-2 items-center justify-end">
            <button class="py-2 px-3 border border-Analytics-sidebar text-Analytics-iconcolor hover:bg-Analytics-iconcolor hover:text-white">Analytics</button>
            <button class="py-2 px-3 border border-Analytics-sidebar text-yellow-500 hover:bg-yellow-600 hover:text-white">Revoke</button>
            <button class="py-2 px-3 border border-Analytics-sidebar text-green-500 hover:bg-green-600 hover:text-white">Aliases</button>
          </div>
        </span>
      </div>
    </div>
  </div>
</div>
<!-- Component End  -->
