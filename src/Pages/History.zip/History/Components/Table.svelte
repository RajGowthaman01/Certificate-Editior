<div class="overflow-hidden shadow ring-1 ring-black ring-opacity-5">
  <table class="min-w-full divide-y divide-Analytics-sidebar">
    <thead class="bg-transparent">
      <tr>
        <th scope="col" class="whitespace-nowrap py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-white sm:pl-6">Document ID</th>
        <th scope="col" class="whitespace-nowrap px-2 py-3.5 text-left text-sm font-semibold text-white">Issuer name</th>
        <th scope="col" class="whitespace-nowrap px-2 py-3.5 text-left text-sm font-semibold text-white">Issued Date</th>
        <th scope="col" class="whitespace-nowrap px-2 py-3.5 text-left text-sm font-semibold text-white">Title</th>
        <th scope="col" class="whitespace-nowrap px-2 py-3.5 text-left text-sm font-semibold text-white">Actions</th>
        <th scope="col" class="whitespace-nowrap px-2 py-3.5 text-left text-sm font-semibold text-white">Status</th>
        <th scope="col" class="relative whitespace-nowrap py-3.5 pl-3 pr-4 sm:pr-6">
          <span class="sr-only">Edit</span>
        </th>
      </tr>
    </thead>
    <tbody class="divide-y divide-Analytics-sidebar bg-transparent">
      <tr>
        <td class="whitespace-nowrap py-2 pl-4 pr-3 text-sm text-Analytics-primarytext sm:pl-6">629743bd6cb6b239c0215563</td>
        <td class="whitespace-nowrap px-2 py-2 text-sm font-medium text-Analytics-primarytext">SIDBI (DEMO)</td>
        <td class="whitespace-nowrap px-2 py-2 text-sm text-Analytics-primarytext">Wed Jun 01 2022</td>
        <td class="whitespace-nowrap px-2 py-2 text-sm text-Analytics-primarytext">Fixed Bank Deposit</td>
        <td class="whitespace-nowrap px-2 py-2 text-sm text-Analytics-primarytext">
          <div class="flex gap-5">
            <button class="b text-blue-600">Analytics</button>
            <button class="  text-green-600">Revoke</button>
            <button class="  text-slate-400">Aliases</button>
          </div>
        </td>
        <td class="whitespace-nowrap px-2 py-2 text-sm text-green-600">Active</td>
        <td class="relative whitespace-nowrap py-2 pl-3 pr-4 text-right text-sm font-medium sm:pr-6">
          <a href="/" class="text-white px-3 py-1 rounded-md bg-Analytics-iconcolor hover:text-primary_blue">
            View
            <span class="sr-only">, AAPS0L</span>
          </a>
        </td>
      </tr>
      <tr>
        <td class="whitespace-nowrap py-2 pl-4 pr-3 text-sm text-Analytics-primarytext sm:pl-6">629743bd6cb6b239c0215563</td>
        <td class="whitespace-nowrap px-2 py-2 text-sm font-medium text-Analytics-primarytext">SIDBI (DEMO)</td>
        <td class="whitespace-nowrap px-2 py-2 text-sm text-Analytics-primarytext">Wed Jun 01 2022</td>
        <td class="whitespace-nowrap px-2 py-2 text-sm text-Analytics-primarytext">Fixed Bank Deposit</td>
        <td class="whitespace-nowrap px-2 py-2 text-sm text-Analytics-primarytext">
          <div class="flex gap-5">
            <button class=" text-blue-600">Analytics</button>
            <button class="  text-green-600">Revoke</button>
            <button class="  text-slate-400">Aliases</button>
          </div>
        </td>
        <td class="whitespace-nowrap px-2 py-2 text-sm text-green-600">Active</td>
        <td class="relative whitespace-nowrap py-2 pl-3 pr-4 text-right text-sm font-medium sm:pr-6">
          <a href="/" class="text-white px-3 py-1 rounded-md bg-Analytics-iconcolor hover:text-primary_blue">
            View
            <span class="sr-only">, AAPS0L</span>
          </a>
        </td>
      </tr>
      <tr>
        <td class="whitespace-nowrap py-2 pl-4 pr-3 text-sm text-Analytics-primarytext sm:pl-6">629743bd6cb6b239c0215563</td>
        <td class="whitespace-nowrap px-2 py-2 text-sm font-medium text-Analytics-primarytext">SIDBI (DEMO)</td>
        <td class="whitespace-nowrap px-2 py-2 text-sm text-Analytics-primarytext">Wed Jun 01 2022</td>
        <td class="whitespace-nowrap px-2 py-2 text-sm text-Analytics-primarytext">Fixed Bank Deposit</td>
        <td class="whitespace-nowrap px-2 py-2 text-sm text-Analytics-primarytext">
          <div class="flex gap-5">
            <button class=" text-blue-600">Analytics</button>
            <button class="  text-green-600">Revoke</button>
            <button class="  text-slate-400">Aliases</button>
          </div>
        </td>
        <td class="whitespace-nowrap px-2 py-2 text-sm text-green-600">Active</td>
        <td class="relative whitespace-nowrap py-2 pl-3 pr-4 text-right text-sm font-medium sm:pr-6">
          <a href="/" class="text-white px-3 py-1 rounded-md bg-Analytics-iconcolor hover:text-primary_blue">
            View
            <span class="sr-only">, AAPS0L</span>
          </a>
        </td>
      </tr>
      <tr>
        <td class="whitespace-nowrap py-2 pl-4 pr-3 text-sm text-Analytics-primarytext sm:pl-6">629743bd6cb6b239c0215563</td>
        <td class="whitespace-nowrap px-2 py-2 text-sm font-medium text-Analytics-primarytext">SIDBI (DEMO)</td>
        <td class="whitespace-nowrap px-2 py-2 text-sm text-Analytics-primarytext">Wed Jun 01 2022</td>
        <td class="whitespace-nowrap px-2 py-2 text-sm text-Analytics-primarytext">Fixed Bank Deposit</td>
        <td class="whitespace-nowrap px-2 py-2 text-sm text-Analytics-primarytext">
          <div class="flex gap-5">
            <button class=" text-blue-600">Analytics</button>
            <button class="  text-green-600">Revoke</button>
            <button class="  text-slate-400">Aliases</button>
          </div>
        </td>
        <td class="whitespace-nowrap px-2 py-2 text-sm text-green-600">Active</td>
        <td class="relative whitespace-nowrap py-2 pl-3 pr-4 text-right text-sm font-medium sm:pr-6">
          <a href="/" class="text-white px-3 py-1 rounded-md bg-Analytics-iconcolor hover:text-primary_blue">
            View
            <span class="sr-only">, AAPS0L</span>
          </a>
        </td>
      </tr>
      <tr>
        <td class="whitespace-nowrap py-2 pl-4 pr-3 text-sm text-Analytics-primarytext sm:pl-6">629743bd6cb6b239c0215563</td>
        <td class="whitespace-nowrap px-2 py-2 text-sm font-medium text-Analytics-primarytext">SIDBI (DEMO)</td>
        <td class="whitespace-nowrap px-2 py-2 text-sm text-Analytics-primarytext">Wed Jun 01 2022</td>
        <td class="whitespace-nowrap px-2 py-2 text-sm text-Analytics-primarytext">Fixed Bank Deposit</td>
        <td class="whitespace-nowrap px-2 py-2 text-sm text-Analytics-primarytext">
          <div class="flex gap-5">
            <button class=" text-blue-600">Analytics</button>
            <button class="  text-green-600">Revoke</button>
            <button class="  text-slate-400">Aliases</button>
          </div>
        </td>
        <td class="whitespace-nowrap px-2 py-2 text-sm text-green-600">Active</td>
        <td class="relative whitespace-nowrap py-2 pl-3 pr-4 text-right text-sm font-medium sm:pr-6">
          <a href="/" class="text-white px-3 py-1 rounded-md bg-Analytics-iconcolor hover:text-primary_blue">
            View
            <span class="sr-only">, AAPS0L</span>
          </a>
        </td>
      </tr>
      <!-- <tr>
        <td class="whitespace-nowrap py-2 pl-4 pr-3 text-sm text-Analytics-primarytext sm:pl-6">629743bd6cb6b239c0215563</td>
        <td class="whitespace-nowrap px-2 py-2 text-sm font-medium text-Analytics-primarytext">SIDBI (DEMO)</td>
        <td class="whitespace-nowrap px-2 py-2 text-sm text-Analytics-primarytext">Wed Jun 01 2022</td>
        <td class="whitespace-nowrap px-2 py-2 text-sm text-Analytics-primarytext">Fixed Bank Deposit</td>
        <td class="whitespace-nowrap px-2 py-2 text-sm text-Analytics-primarytext">
          <div class="flex gap-5">
            <button class=" text-blue-600">Analytics</button>
            <button class="  text-green-600">Revoke</button>
            <button class="  text-slate-400">Aliases</button>
          </div>
        </td>
        <td class="whitespace-nowrap px-2 py-2 text-sm text-green-600">Active</td>
        <td class="relative whitespace-nowrap py-2 pl-3 pr-4 text-right text-sm font-medium sm:pr-6">
          <a href="/" class="text-white px-3 py-1 rounded-md bg-Analytics-iconcolor hover:text-primary_blue">
            View
            <span class="sr-only">, AAPS0L</span>
          </a>
        </td>
      </tr> -->
    </tbody>
  </table>
</div>
